import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
public class Scorepanel extends Actor
{
    public void act() 
    {
        // Add your action code here.
    }    
}
