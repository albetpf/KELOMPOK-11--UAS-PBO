import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
public class Portal extends Actor
{
    public void act() 
    {
        // Add your action code here.
    }    
}
